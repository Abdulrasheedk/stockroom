from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Product, StockLine, User
from ..schemas import ProductIn
from ..security import admin_only, current_user, scope_warehouse
from ..services import export_response, find_product, onhand_for, read_table, search_products_cond, template_response

router = APIRouter(prefix="/api/products")

COLUMNS = [{"key": "sku", "label": "SKU#"}, {"key": "name", "label": "Product name"},
           {"key": "brand", "label": "Brand"}, {"key": "uom", "label": "UOM"},
           {"key": "barcode", "label": "Barcode"}, {"key": "min_stock", "label": "Min stock"},
           {"key": "active", "label": "Active"}]


def p_out(p: Product) -> dict:
    return {"id": p.id, "sku": p.sku, "name": p.name, "brand": p.brand, "uom": p.uom,
            "barcode": p.barcode, "min_stock": p.min_stock, "active": p.active}


def _filtered(q: str, brand: str, active: str):
    stmt = select(Product)
    if q:
        stmt = stmt.where(search_products_cond(q))
    if brand:
        stmt = stmt.where(Product.brand == brand)
    if active == "1":
        stmt = stmt.where(Product.active.is_(True))
    elif active == "0":
        stmt = stmt.where(Product.active.is_(False))
    return stmt


@router.get("")
def list_products(q: str = "", brand: str = "", active: str = "", limit: int = 50, offset: int = 0,
                  fmt: str = "json", _: User = Depends(current_user), db: Session = Depends(get_db)):
    stmt = _filtered(q, brand, active).order_by(Product.sku)
    if fmt in ("xlsx", "csv"):
        rows = [p_out(p) | {"active": "Yes" if p.active else "No"} for p in db.execute(stmt).scalars()]
        return export_response(rows, COLUMNS, fmt, "products")
    total = db.execute(select(func.count()).select_from(stmt.subquery())).scalar()
    items = db.execute(stmt.limit(min(limit, 500)).offset(offset)).scalars()
    return {"total": total, "items": [p_out(p) for p in items]}


@router.get("/brands")
def brands(_: User = Depends(current_user), db: Session = Depends(get_db)):
    q = select(Product.brand).where(Product.brand != "").distinct().order_by(Product.brand)
    return list(db.execute(q).scalars())


@router.get("/lookup")
def lookup(code: str, warehouse_id: int | None = None, user: User = Depends(current_user),
           db: Session = Depends(get_db)):
    """Used by entry screens: type/scan a SKU or barcode, get product details (+ on-hand)."""
    p = find_product(db, code)
    if not p:
        raise HTTPException(404, f"No product found for '{code}'")
    out = p_out(p)
    wid = scope_warehouse(user, warehouse_id)
    if wid:
        out["on_hand"] = onhand_for(db, wid, [p.id]).get(p.id, 0)
    return out


@router.get("/template")
def template(_: User = Depends(current_user)):
    return template_response(
        ["SKU#", "Product Name", "Brand", "UOM", "Barcode", "Min Stock"],
        [["SKU-0001", "Sample product", "Acme", "PCS", "6291000000017", 10]], "products_template")


@router.post("")
def add_product(body: ProductIn, _: User = Depends(admin_only), db: Session = Depends(get_db)):
    p = Product(**{**body.model_dump(), "sku": body.sku.strip(), "name": body.name.strip(),
                   "barcode": body.barcode.strip(), "brand": body.brand.strip(), "uom": body.uom.strip() or "PCS"})
    db.add(p)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(400, f"SKU '{body.sku}' already exists")
    return p_out(p)


@router.put("/{pid}")
def edit_product(pid: int, body: ProductIn, _: User = Depends(admin_only), db: Session = Depends(get_db)):
    p = db.get(Product, pid)
    if not p:
        raise HTTPException(404, "Product not found")
    for k, v in body.model_dump().items():
        setattr(p, k, v.strip() if isinstance(v, str) else v)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(400, f"SKU '{body.sku}' already exists")
    return p_out(p)


@router.delete("/{pid}")
def delete_product(pid: int, _: User = Depends(admin_only), db: Session = Depends(get_db)):
    p = db.get(Product, pid)
    if not p:
        raise HTTPException(404, "Product not found")
    used = db.execute(select(func.count()).select_from(StockLine).where(StockLine.product_id == pid)).scalar()
    if used:
        p.active = False
        db.commit()
        return {"ok": True, "message": "Product has stock history, so it was deactivated instead of deleted"}
    db.delete(p)
    db.commit()
    return {"ok": True, "message": "Product deleted"}


@router.post("/bulk")
def bulk_products(file: UploadFile = File(...), _: User = Depends(admin_only), db: Session = Depends(get_db)):
    """Create new SKUs and update existing ones (matched by SKU#). Blank cells keep the current value."""
    rows = read_table(file)
    existing = {p.sku.lower(): p for p in db.execute(select(Product)).scalars()}
    created = updated = 0
    errors = []
    for r in rows:
        sku = r.get("sku", "")
        if not sku:
            errors.append({"row": r["_row"], "error": "SKU# is empty"})
            continue
        try:
            min_stock = float(r["min_stock"]) if r.get("min_stock") else None
        except ValueError:
            errors.append({"row": r["_row"], "error": f"Min stock '{r['min_stock']}' is not a number"})
            continue
        p = existing.get(sku.lower())
        if p:
            for f in ("name", "brand", "uom", "barcode"):
                if r.get(f):
                    setattr(p, f, r[f])
            if min_stock is not None:
                p.min_stock = min_stock
            updated += 1
        else:
            if not r.get("name"):
                errors.append({"row": r["_row"], "error": f"Product name is empty for new SKU {sku}"})
                continue
            p = Product(sku=sku, name=r["name"], brand=r.get("brand", ""), uom=r.get("uom") or "PCS",
                        barcode=r.get("barcode", ""), min_stock=min_stock or 0)
            db.add(p)
            existing[sku.lower()] = p
            created += 1
    db.commit()
    return {"created": created, "updated": updated, "errors": errors[:200], "error_count": len(errors)}
