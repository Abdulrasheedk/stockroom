"""Inbound / outbound documents."""
from collections import defaultdict
from datetime import date

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Product, StockDoc, StockLine, User, Warehouse
from ..schemas import DocIn
from ..security import admin_only, current_user, scope_warehouse
from ..services import (ALLOW_NEGATIVE, create_doc, export_response, find_product, onhand_for, parse_date,
                        read_table, signed_qty, template_response)

router = APIRouter(prefix="/api/docs")

DOC_COLUMNS = [{"key": "doc_no", "label": "Doc no"}, {"key": "doc_date", "label": "Date"},
               {"key": "type", "label": "Type"}, {"key": "warehouse", "label": "Warehouse"},
               {"key": "reference", "label": "Reference"}, {"key": "lines", "label": "Lines"},
               {"key": "total_qty", "label": "Total qty"}, {"key": "user", "label": "Entered by"},
               {"key": "remarks", "label": "Remarks"}]


def _type_label(t: str) -> str:
    return "Inbound" if t == "IN" else "Outbound"


@router.get("")
def list_docs(warehouse_id: int | None = None, doc_type: str = "", date_from: date | None = None,
              date_to: date | None = None, q: str = "", limit: int = 50, offset: int = 0, fmt: str = "json",
              user: User = Depends(current_user), db: Session = Depends(get_db)):
    wid = scope_warehouse(user, warehouse_id)
    agg = (select(StockLine.doc_id, func.count().label("n"), func.sum(StockLine.qty).label("qty"))
           .group_by(StockLine.doc_id).subquery())
    stmt = (select(StockDoc, Warehouse.code, User.username, agg.c.n, agg.c.qty)
            .join(Warehouse, Warehouse.id == StockDoc.warehouse_id)
            .outerjoin(User, User.id == StockDoc.created_by)
            .outerjoin(agg, agg.c.doc_id == StockDoc.id))
    if wid:
        stmt = stmt.where(StockDoc.warehouse_id == wid)
    if doc_type in ("IN", "OUT"):
        stmt = stmt.where(StockDoc.doc_type == doc_type)
    if date_from:
        stmt = stmt.where(StockDoc.doc_date >= date_from)
    if date_to:
        stmt = stmt.where(StockDoc.doc_date <= date_to)
    if q:
        t = f"%{q.strip()}%"
        stmt = stmt.where(StockDoc.doc_no.ilike(t) | StockDoc.reference.ilike(t) | StockDoc.remarks.ilike(t))
    stmt = stmt.order_by(StockDoc.doc_date.desc(), StockDoc.id.desc())
    total = db.execute(select(func.count()).select_from(stmt.order_by(None).subquery())).scalar()
    if fmt not in ("xlsx", "csv"):
        stmt = stmt.limit(min(limit, 500)).offset(offset)
    rows = [{"id": d.id, "doc_no": d.doc_no, "doc_date": d.doc_date.isoformat(), "doc_type": d.doc_type,
             "type": _type_label(d.doc_type), "warehouse": wc, "reference": d.reference, "remarks": d.remarks,
             "lines": n or 0, "total_qty": float(qty or 0), "user": un or ""}
            for d, wc, un, n, qty in db.execute(stmt)]
    if fmt in ("xlsx", "csv"):
        return export_response(rows, DOC_COLUMNS, fmt, "transactions")
    return {"total": total, "items": rows}


@router.get("/template")
def template(_: User = Depends(current_user)):
    return template_response(
        ["Type", "Warehouse", "Date", "Reference", "SKU#", "Qty", "Remarks"],
        [["IN", "MAIN", "2026-09-28", "PO-1001", "SKU-0001", 100, "Supplier delivery"],
         ["OUT", "MAIN", "2026-09-28", "DO-2001", "SKU-0001", 10, "Customer order"]], "transactions_template")


@router.get("/{did}")
def get_doc(did: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    d = db.get(StockDoc, did)
    if not d:
        raise HTTPException(404, "Transaction not found")
    scope_warehouse(user, d.warehouse_id)
    return {"id": d.id, "doc_no": d.doc_no, "doc_type": d.doc_type, "warehouse": d.warehouse.code,
            "warehouse_name": d.warehouse.name, "doc_date": d.doc_date.isoformat(), "reference": d.reference,
            "remarks": d.remarks, "user": d.user.username if d.user else "",
            "lines": [{"sku": l.product.sku, "name": l.product.name, "brand": l.product.brand,
                       "uom": l.product.uom, "barcode": l.product.barcode, "qty": l.qty, "remarks": l.remarks}
                      for l in d.lines]}


@router.post("")
def add_doc(body: DocIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    scope_warehouse(user, body.warehouse_id)
    lines, missing = [], []
    for l in body.lines:
        p = find_product(db, l.code)
        if not p:
            missing.append(l.code)
        else:
            lines.append((p, l.qty, l.remarks))
    if missing:
        raise HTTPException(400, "Unknown SKU/barcode: " + ", ".join(missing[:10]))
    doc = create_doc(db, user, body.doc_type, body.warehouse_id, body.doc_date, body.reference, body.remarks, lines)
    db.commit()
    return {"id": doc.id, "doc_no": doc.doc_no}


@router.delete("/{did}")
def delete_doc(did: int, _: User = Depends(admin_only), db: Session = Depends(get_db)):
    d = db.get(StockDoc, did)
    if not d:
        raise HTTPException(404, "Transaction not found")
    if d.doc_type == "IN" and not ALLOW_NEGATIVE:
        need = defaultdict(float)
        for l in d.lines:
            need[l.product_id] += l.qty
        have = onhand_for(db, d.warehouse_id, list(need))
        for pid, q in need.items():
            if have.get(pid, 0) - q < -1e-9:
                sku = db.get(Product, pid).sku
                raise HTTPException(400, f"Cannot delete: stock of {sku} has already been issued out, "
                                         "deleting this inbound would make it negative")
    db.delete(d)
    db.commit()
    return {"ok": True, "message": f"{d.doc_no} deleted"}


@router.post("/bulk")
def bulk_docs(file: UploadFile = File(...), user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Upload many inbound/outbound lines at once. All-or-nothing: if any row is wrong nothing is saved."""
    rows = read_table(file)
    whs = {w.code.lower(): w for w in db.execute(select(Warehouse)).scalars()}
    sku_map, bc_map = {}, {}
    for p in db.execute(select(Product).where(Product.active.is_(True))).scalars():
        sku_map[p.sku.lower()] = p
        if p.barcode:
            bc_map[p.barcode] = p
    errors, groups = [], {}
    for r in rows:
        n = r["_row"]
        t = r.get("type", "").upper()
        t = {"IN": "IN", "INBOUND": "IN", "RECEIVE": "IN", "OUT": "OUT", "OUTBOUND": "OUT", "ISSUE": "OUT"}.get(t)
        if not t:
            errors.append({"row": n, "error": "Type must be IN or OUT"})
            continue
        wcode = r.get("warehouse", "")
        if not wcode and user.warehouse_id:
            wh = db.get(Warehouse, user.warehouse_id)
        else:
            wh = whs.get(wcode.lower())
        if not wh or not wh.active:
            errors.append({"row": n, "error": f"Warehouse '{wcode}' not found"})
            continue
        if user.warehouse_id and wh.id != user.warehouse_id:
            errors.append({"row": n, "error": f"You cannot post to warehouse {wh.code}"})
            continue
        code = r.get("sku", "")
        p = sku_map.get(code.lower()) or bc_map.get(code)
        if not p:
            errors.append({"row": n, "error": f"SKU/barcode '{code}' not found in product database"})
            continue
        try:
            qty = float(r.get("qty", ""))
            if qty <= 0:
                raise ValueError
        except ValueError:
            errors.append({"row": n, "error": f"Qty '{r.get('qty', '')}' must be a number above 0"})
            continue
        try:
            dt = parse_date(r.get("date", ""))
        except ValueError as e:
            errors.append({"row": n, "error": str(e)})
            continue
        groups.setdefault((t, wh.id, dt, r.get("reference", "")), []).append((p, qty, r.get("remarks", "")))
    if errors:
        raise HTTPException(400, {"message": f"{len(errors)} row(s) have problems. Nothing was saved.",
                                  "errors": errors[:200]})
    docs = []
    try:
        for (t, wid, dt, ref), lines in groups.items():
            docs.append(create_doc(db, user, t, wid, dt, ref, "Bulk upload", lines).doc_no)
        db.commit()
    except HTTPException as e:
        db.rollback()
        raise HTTPException(400, {"message": f"{e.detail}. Nothing was saved.", "errors": []})
    return {"documents": len(docs), "lines": sum(len(v) for v in groups.values()), "doc_nos": docs[:50]}
