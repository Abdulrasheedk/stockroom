"""Login, users and warehouses."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import StockDoc, User, Warehouse
from ..schemas import LoginIn, PasswordIn, UserIn, WarehouseIn
from ..security import admin_only, current_user, hash_password, make_token, verify_password

router = APIRouter(prefix="/api")


def user_out(u: User) -> dict:
    return {"id": u.id, "username": u.username, "full_name": u.full_name, "role": u.role,
            "active": u.active, "warehouse_id": u.warehouse_id}


def wh_out(w: Warehouse) -> dict:
    return {"id": w.id, "code": w.code, "name": w.name, "location": w.location, "active": w.active}


# ------------------------------------------------------------------ auth
@router.post("/auth/login")
def login(body: LoginIn, db: Session = Depends(get_db)):
    u = db.execute(select(User).where(func.lower(User.username) == body.username.strip().lower())).scalar_one_or_none()
    if not u or not u.active or not verify_password(body.password, u.password_hash):
        raise HTTPException(401, "Wrong username or password")
    return {"token": make_token(u), "user": user_out(u)}


@router.get("/auth/me")
def me(user: User = Depends(current_user)):
    return user_out(user)


@router.post("/auth/password")
def change_password(body: PasswordIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    if not verify_password(body.old_password, user.password_hash):
        raise HTTPException(400, "Current password is wrong")
    user.password_hash = hash_password(body.new_password)
    db.commit()
    return {"ok": True}


# ------------------------------------------------------------------ users (admin)
@router.get("/users")
def list_users(_: User = Depends(admin_only), db: Session = Depends(get_db)):
    return [user_out(u) for u in db.execute(select(User).order_by(User.username)).scalars()]


@router.post("/users")
def add_user(body: UserIn, _: User = Depends(admin_only), db: Session = Depends(get_db)):
    if not body.password or len(body.password) < 6:
        raise HTTPException(400, "Password must be at least 6 characters")
    u = User(username=body.username.strip(), full_name=body.full_name, role=body.role, active=body.active,
             warehouse_id=body.warehouse_id, password_hash=hash_password(body.password))
    db.add(u)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(400, "Username already exists")
    return user_out(u)


@router.put("/users/{uid}")
def edit_user(uid: int, body: UserIn, admin: User = Depends(admin_only), db: Session = Depends(get_db)):
    u = db.get(User, uid)
    if not u:
        raise HTTPException(404, "User not found")
    if u.id == admin.id and (body.role != "admin" or not body.active):
        raise HTTPException(400, "You cannot remove your own admin access")
    u.username, u.full_name, u.role = body.username.strip(), body.full_name, body.role
    u.active, u.warehouse_id = body.active, body.warehouse_id
    if body.password:
        if len(body.password) < 6:
            raise HTTPException(400, "Password must be at least 6 characters")
        u.password_hash = hash_password(body.password)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(400, "Username already exists")
    return user_out(u)


@router.delete("/users/{uid}")
def delete_user(uid: int, admin: User = Depends(admin_only), db: Session = Depends(get_db)):
    u = db.get(User, uid)
    if not u:
        raise HTTPException(404, "User not found")
    if u.id == admin.id:
        raise HTTPException(400, "You cannot delete your own account")
    used = db.execute(select(func.count()).select_from(StockDoc).where(StockDoc.created_by == uid)).scalar()
    if used:
        u.active = False
        db.commit()
        return {"ok": True, "message": "User has transaction history, so the account was disabled instead of deleted"}
    db.delete(u)
    db.commit()
    return {"ok": True, "message": "User deleted"}


# ------------------------------------------------------------------ warehouses
@router.get("/warehouses")
def list_warehouses(user: User = Depends(current_user), db: Session = Depends(get_db)):
    q = select(Warehouse).order_by(Warehouse.code)
    if user.warehouse_id:
        q = q.where(Warehouse.id == user.warehouse_id)
    return [wh_out(w) for w in db.execute(q).scalars()]


@router.post("/warehouses")
def add_warehouse(body: WarehouseIn, _: User = Depends(admin_only), db: Session = Depends(get_db)):
    w = Warehouse(code=body.code.strip().upper(), name=body.name.strip(), location=body.location, active=body.active)
    db.add(w)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(400, "Warehouse code already exists")
    return wh_out(w)


@router.put("/warehouses/{wid}")
def edit_warehouse(wid: int, body: WarehouseIn, _: User = Depends(admin_only), db: Session = Depends(get_db)):
    w = db.get(Warehouse, wid)
    if not w:
        raise HTTPException(404, "Warehouse not found")
    w.code, w.name, w.location, w.active = body.code.strip().upper(), body.name.strip(), body.location, body.active
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(400, "Warehouse code already exists")
    return wh_out(w)


@router.delete("/warehouses/{wid}")
def delete_warehouse(wid: int, _: User = Depends(admin_only), db: Session = Depends(get_db)):
    w = db.get(Warehouse, wid)
    if not w:
        raise HTTPException(404, "Warehouse not found")
    used = db.execute(select(func.count()).select_from(StockDoc).where(StockDoc.warehouse_id == wid)).scalar()
    if used:
        w.active = False
        db.commit()
        return {"ok": True, "message": "Warehouse has stock history, so it was deactivated instead of deleted"}
    db.execute(User.__table__.update().where(User.warehouse_id == wid).values(warehouse_id=None))
    db.delete(w)
    db.commit()
    return {"ok": True, "message": "Warehouse deleted"}
