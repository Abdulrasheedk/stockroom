"""Reports (with filters + export) and dashboard."""
from datetime import date, timedelta

from fastapi import APIRouter, Depends
from sqlalchemy import case, func, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Product, StockDoc, StockLine, User, Warehouse
from ..security import current_user, scope_warehouse
from ..services import export_response, search_products_cond, signed_qty

router = APIRouter(prefix="/api")


def _f(x):
    return round(float(x or 0), 3)


def _finish(db, stmt, mapper, cols, name, fmt, limit, offset):
    if fmt in ("xlsx", "csv"):
        return export_response([mapper(r) for r in db.execute(stmt)], cols, fmt, name)
    total = db.execute(select(func.count()).select_from(stmt.order_by(None).subquery())).scalar()
    rows = [mapper(r) for r in db.execute(stmt.limit(min(limit, 1000)).offset(offset))]
    return {"columns": cols, "rows": rows, "total": total}


@router.get("/reports/onhand")
def onhand(warehouse_id: int | None = None, brand: str = "", q: str = "", group: str = "warehouse",
           hide_zero: bool = False, limit: int = 200, offset: int = 0, fmt: str = "json",
           user: User = Depends(current_user), db: Session = Depends(get_db)):
    wid = scope_warehouse(user, warehouse_id)
    inq = func.sum(case((StockDoc.doc_type == "IN", StockLine.qty), else_=0))
    outq = func.sum(case((StockDoc.doc_type == "OUT", StockLine.qty), else_=0))
    by_wh = group == "warehouse"
    cols_sel = [Warehouse.code, Warehouse.name.label("wh_name")] if by_wh else []
    stmt = (select(*cols_sel, Product.sku, Product.name, Product.brand, Product.uom, Product.barcode,
                   Product.min_stock, inq.label("i"), outq.label("o"))
            .select_from(StockLine).join(StockDoc, StockDoc.id == StockLine.doc_id)
            .join(Product, Product.id == StockLine.product_id).join(Warehouse, Warehouse.id == StockDoc.warehouse_id))
    if wid:
        stmt = stmt.where(StockDoc.warehouse_id == wid)
    if brand:
        stmt = stmt.where(Product.brand == brand)
    if q:
        stmt = stmt.where(search_products_cond(q))
    gb = ([Warehouse.code, Warehouse.name] if by_wh else []) + [
        Product.id, Product.sku, Product.name, Product.brand, Product.uom, Product.barcode, Product.min_stock]
    stmt = stmt.group_by(*gb)
    if hide_zero:
        stmt = stmt.having(inq - outq != 0)
    stmt = stmt.order_by(*(([Warehouse.code]) if by_wh else []), Product.sku)

    def mapper(r):
        m = r._mapping
        i, o = _f(m["i"]), _f(m["o"])
        d = {"sku": m["sku"], "name": m["name"], "brand": m["brand"], "uom": m["uom"], "barcode": m["barcode"],
             "total_in": i, "total_out": o, "on_hand": round(i - o, 3), "min_stock": m["min_stock"]}
        if by_wh:
            d["warehouse"] = m["code"]
        return d

    cols = ([{"key": "warehouse", "label": "Warehouse"}] if by_wh else []) + [
        {"key": "sku", "label": "SKU#"}, {"key": "name", "label": "Product name"}, {"key": "brand", "label": "Brand"},
        {"key": "uom", "label": "UOM"}, {"key": "barcode", "label": "Barcode"}, {"key": "total_in", "label": "Total in"},
        {"key": "total_out", "label": "Total out"}, {"key": "on_hand", "label": "On hand"}]
    return _finish(db, stmt, mapper, cols, "on_hand_stock", fmt, limit, offset)


@router.get("/reports/movements")
def movements(warehouse_id: int | None = None, doc_type: str = "", date_from: date | None = None,
              date_to: date | None = None, brand: str = "", q: str = "", reference: str = "",
              limit: int = 200, offset: int = 0, fmt: str = "json",
              user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Line-level inbound / outbound report."""
    wid = scope_warehouse(user, warehouse_id)
    stmt = (select(StockDoc.doc_no, StockDoc.doc_date, StockDoc.doc_type, Warehouse.code, StockDoc.reference,
                   Product.sku, Product.name, Product.brand, Product.uom, Product.barcode, StockLine.qty,
                   StockLine.remarks, User.username)
            .select_from(StockLine).join(StockDoc, StockDoc.id == StockLine.doc_id)
            .join(Product, Product.id == StockLine.product_id).join(Warehouse, Warehouse.id == StockDoc.warehouse_id)
            .outerjoin(User, User.id == StockDoc.created_by))
    if wid:
        stmt = stmt.where(StockDoc.warehouse_id == wid)
    if doc_type in ("IN", "OUT"):
        stmt = stmt.where(StockDoc.doc_type == doc_type)
    if date_from:
        stmt = stmt.where(StockDoc.doc_date >= date_from)
    if date_to:
        stmt = stmt.where(StockDoc.doc_date <= date_to)
    if brand:
        stmt = stmt.where(Product.brand == brand)
    if q:
        stmt = stmt.where(search_products_cond(q))
    if reference:
        stmt = stmt.where(StockDoc.reference.ilike(f"%{reference.strip()}%"))
    stmt = stmt.order_by(StockDoc.doc_date.desc(), StockDoc.id.desc(), StockLine.id)

    def mapper(r):
        return {"doc_no": r[0], "date": r[1].isoformat(), "type": "Inbound" if r[2] == "IN" else "Outbound",
                "warehouse": r[3], "reference": r[4], "sku": r[5], "name": r[6], "brand": r[7], "uom": r[8],
                "barcode": r[9], "qty": r[10], "remarks": r[11], "user": r[12] or ""}

    cols = [{"key": k, "label": l} for k, l in [
        ("date", "Date"), ("doc_no", "Doc no"), ("type", "Type"), ("warehouse", "Warehouse"),
        ("reference", "Reference"), ("sku", "SKU#"), ("name", "Product name"), ("brand", "Brand"),
        ("uom", "UOM"), ("barcode", "Barcode"), ("qty", "Qty"), ("remarks", "Remarks"), ("user", "Entered by")]]
    return _finish(db, stmt, mapper, cols, "stock_movements", fmt, limit, offset)


@router.get("/reports/summary")
def summary(warehouse_id: int | None = None, date_from: date | None = None, date_to: date | None = None,
            brand: str = "", q: str = "", limit: int = 200, offset: int = 0, fmt: str = "json",
            user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Total inbound vs outbound per SKU in a period."""
    wid = scope_warehouse(user, warehouse_id)
    inq = func.sum(case((StockDoc.doc_type == "IN", StockLine.qty), else_=0))
    outq = func.sum(case((StockDoc.doc_type == "OUT", StockLine.qty), else_=0))
    stmt = (select(Product.sku, Product.name, Product.brand, Product.uom, inq.label("i"), outq.label("o"))
            .select_from(StockLine).join(StockDoc, StockDoc.id == StockLine.doc_id)
            .join(Product, Product.id == StockLine.product_id))
    if wid:
        stmt = stmt.where(StockDoc.warehouse_id == wid)
    if date_from:
        stmt = stmt.where(StockDoc.doc_date >= date_from)
    if date_to:
        stmt = stmt.where(StockDoc.doc_date <= date_to)
    if brand:
        stmt = stmt.where(Product.brand == brand)
    if q:
        stmt = stmt.where(search_products_cond(q))
    stmt = stmt.group_by(Product.id, Product.sku, Product.name, Product.brand, Product.uom).order_by(Product.sku)

    def mapper(r):
        i, o = _f(r[4]), _f(r[5])
        return {"sku": r[0], "name": r[1], "brand": r[2], "uom": r[3], "total_in": i, "total_out": o,
                "net": round(i - o, 3)}

    cols = [{"key": k, "label": l} for k, l in [("sku", "SKU#"), ("name", "Product name"), ("brand", "Brand"),
            ("uom", "UOM"), ("total_in", "Total in"), ("total_out", "Total out"), ("net", "Net change")]]
    return _finish(db, stmt, mapper, cols, "inbound_outbound_summary", fmt, limit, offset)


def _low_stock_stmt(wid):
    oh = (select(StockLine.product_id.label("pid"), func.sum(signed_qty()).label("oh"))
          .join(StockDoc, StockDoc.id == StockLine.doc_id).group_by(StockLine.product_id))
    if wid:
        oh = oh.where(StockDoc.warehouse_id == wid)
    oh = oh.subquery()
    have = func.coalesce(oh.c.oh, 0)
    return (select(Product.sku, Product.name, Product.brand, Product.uom, Product.min_stock, have.label("have"))
            .outerjoin(oh, oh.c.pid == Product.id)
            .where(Product.active.is_(True), Product.min_stock > 0, have <= Product.min_stock)
            .order_by(Product.sku))


@router.get("/reports/lowstock")
def lowstock(warehouse_id: int | None = None, limit: int = 200, offset: int = 0, fmt: str = "json",
             user: User = Depends(current_user), db: Session = Depends(get_db)):
    wid = scope_warehouse(user, warehouse_id)

    def mapper(r):
        return {"sku": r[0], "name": r[1], "brand": r[2], "uom": r[3], "min_stock": r[4],
                "on_hand": _f(r[5]), "shortage": round(r[4] - _f(r[5]), 3)}

    cols = [{"key": k, "label": l} for k, l in [("sku", "SKU#"), ("name", "Product name"), ("brand", "Brand"),
            ("uom", "UOM"), ("min_stock", "Min stock"), ("on_hand", "On hand"), ("shortage", "Shortage")]]
    return _finish(db, _low_stock_stmt(wid), mapper, cols, "low_stock", fmt, limit, offset)


@router.get("/dashboard")
def dashboard(warehouse_id: int | None = None, user: User = Depends(current_user), db: Session = Depends(get_db)):
    wid = scope_warehouse(user, warehouse_id)
    today = date.today()

    def scoped(stmt):
        return stmt.where(StockDoc.warehouse_id == wid) if wid else stmt

    base = select(StockLine).join(StockDoc, StockDoc.id == StockLine.doc_id)  # noqa: F841
    total_on_hand = db.execute(scoped(
        select(func.coalesce(func.sum(signed_qty()), 0)).join(StockDoc, StockDoc.id == StockLine.doc_id))).scalar()

    def period(d1, d2=None):
        cond = [StockDoc.doc_date >= d1] + ([StockDoc.doc_date <= d2] if d2 else [])
        r = db.execute(scoped(select(
            func.coalesce(func.sum(case((StockDoc.doc_type == "IN", StockLine.qty), else_=0)), 0),
            func.coalesce(func.sum(case((StockDoc.doc_type == "OUT", StockLine.qty), else_=0)), 0))
            .join(StockDoc, StockDoc.id == StockLine.doc_id).where(*cond))).one()
        return {"in": _f(r[0]), "out": _f(r[1])}

    series_start = today - timedelta(days=13)
    rows = db.execute(scoped(select(StockDoc.doc_date, StockDoc.doc_type, func.sum(StockLine.qty))
                             .join(StockLine, StockLine.doc_id == StockDoc.id)
                             .where(StockDoc.doc_date >= series_start)
                             .group_by(StockDoc.doc_date, StockDoc.doc_type))).all()
    by_day = {}
    for d, t, q in rows:
        by_day.setdefault(d, {"in": 0, "out": 0})["in" if t == "IN" else "out"] = _f(q)
    series = [{"date": (series_start + timedelta(days=i)).isoformat(),
               **by_day.get(series_start + timedelta(days=i), {"in": 0, "out": 0})} for i in range(14)]

    top = db.execute(scoped(select(Product.sku, Product.name, func.sum(StockLine.qty).label("q"))
                            .select_from(StockLine).join(StockDoc, StockDoc.id == StockLine.doc_id)
                            .join(Product, Product.id == StockLine.product_id)
                            .where(StockDoc.doc_type == "OUT", StockDoc.doc_date >= today - timedelta(days=30))
                            .group_by(Product.id, Product.sku, Product.name)
                            .order_by(func.sum(StockLine.qty).desc()).limit(5))).all()

    wh_rows = db.execute(scoped(select(Warehouse.code, Warehouse.name, func.sum(signed_qty()),
                                       func.count(func.distinct(StockLine.product_id)))
                                .select_from(StockLine).join(StockDoc, StockDoc.id == StockLine.doc_id)
                                .join(Warehouse, Warehouse.id == StockDoc.warehouse_id)
                                .group_by(Warehouse.id, Warehouse.code, Warehouse.name)
                                .order_by(Warehouse.code))).all()

    recent = db.execute(scoped(select(StockDoc, Warehouse.code).join(Warehouse, Warehouse.id == StockDoc.warehouse_id)
                               .order_by(StockDoc.id.desc()).limit(8))).all()
    low_total = db.execute(select(func.count()).select_from(_low_stock_stmt(wid).order_by(None).subquery())).scalar()

    return {
        "active_skus": db.execute(select(func.count()).select_from(Product).where(Product.active.is_(True))).scalar(),
        "total_on_hand": _f(total_on_hand),
        "today": period(today), "month": period(today.replace(day=1)),
        "low_stock_count": low_total,
        "series": series,
        "top_out": [{"sku": s, "name": n, "qty": _f(q)} for s, n, q in top],
        "by_warehouse": [{"code": c, "name": n, "on_hand": _f(q), "skus": k} for c, n, q, k in wh_rows],
        "recent": [{"id": d.id, "doc_no": d.doc_no, "doc_type": d.doc_type, "warehouse": c,
                    "date": d.doc_date.isoformat(), "reference": d.reference} for d, c in recent],
    }
