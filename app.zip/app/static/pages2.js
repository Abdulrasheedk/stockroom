'use strict';
/* ================= Reports ================= */
const REPORTS = {
  onhand: { label: 'On-hand stock', filters: ['wh', 'brand', 'q', 'group', 'hide'] },
  movements: { label: 'Inbound / outbound', filters: ['wh', 'type', 'from', 'to', 'brand', 'q', 'ref'] },
  summary: { label: 'In vs out by SKU', filters: ['wh', 'from', 'to', 'brand', 'q'] },
  lowstock: { label: 'Low stock', filters: ['wh'] },
};
const FILTER_UI = {
  wh: () => `<label class="f">Warehouse<select id="f-wh">${optHtml(whOptions(true))}</select></label>`,
  brand: () => `<label class="f">Brand<select id="f-brand">${optHtml([['', 'All brands']].concat(S.brands.map(b => [b, b])))}</select></label>`,
  q: () => `<label class="f">SKU / name / barcode<input id="f-q"></label>`,
  group: () => `<label class="f">Show<select id="f-group"><option value="warehouse">Per warehouse</option><option value="product">All warehouses combined</option></select></label>`,
  hide: () => `<label class="chk"><input type="checkbox" id="f-hide"> Hide zero balance</label>`,
  type: () => `<label class="f">Type<select id="f-type"><option value="">Inbound + outbound</option><option value="IN">Inbound only</option><option value="OUT">Outbound only</option></select></label>`,
  from: () => `<label class="f">From<input id="f-from" type="date"></label>`,
  to: () => `<label class="f">To<input id="f-to" type="date"></label>`,
  ref: () => `<label class="f">Reference<input id="f-ref"></label>`,
};
ROUTES.reports = {
  title: 'Reports',
  async render(main) {
    let tab = { lowstock: 'lowstock' }[location.hash.split('?')[1]] || 'onhand', offset = 0; const L = 100;
    const draw = () => {
      main.innerHTML = `<div class="pagehead"><h1>Reports</h1><div class="row">
        <button class="btn" id="x-xlsx">Export Excel</button><button class="btn" id="x-csv">Export CSV</button></div></div>
        <div class="tabs" role="tablist">${Object.entries(REPORTS).map(([k, v]) => `<button role="tab" data-t="${k}" class="${k === tab ? 'on' : ''}">${v.label}</button>`).join('')}</div>
        <div class="filters">${REPORTS[tab].filters.map(f => FILTER_UI[f]()).join('')}<button class="btn primary" id="f-go">Apply filters</button></div>
        <div id="tbl"></div><div id="pg"></div>`;
      $$('.tabs button').forEach(b => b.onclick = () => { tab = b.dataset.t; offset = 0; draw(); });
      $('#f-go').onclick = () => { offset = 0; run(); };
      $('#x-xlsx').onclick = () => download(`/reports/${tab}?` + qs({ ...params(), fmt: 'xlsx' }), `${tab}.xlsx`);
      $('#x-csv').onclick = () => download(`/reports/${tab}?` + qs({ ...params(), fmt: 'csv' }), `${tab}.csv`);
      run();
    };
    const val = id => { const e = $('#' + id); return e ? (e.type === 'checkbox' ? e.checked : e.value) : ''; };
    const params = () => ({ warehouse_id: val('f-wh'), brand: val('f-brand'), q: val('f-q'), group: val('f-group'), hide_zero: val('f-hide'),
      doc_type: val('f-type'), date_from: val('f-from'), date_to: val('f-to'), reference: val('f-ref') });
    async function run() {
      try {
        const r = await api(`/reports/${tab}?` + qs({ ...params(), limit: L, offset }));
        $('#tbl').innerHTML = table(r.columns, r.rows, {
          empty: 'No rows match these filters.',
          rowClass: x => tab === 'onhand' || tab === 'lowstock' ? (x.on_hand < 0 ? 'neg' : (x.min_stock > 0 && x.on_hand <= x.min_stock ? 'low' : '')) : '' });
        pager($('#pg'), r.total, offset, L, o => { offset = o; run(); });
        if (r.total > L) $('#pg').insertAdjacentHTML('beforeend', '<p class="muted small">Exports include every matching row, not only this page.</p>');
      } catch (e) { toast(e.message, 'err'); }
    }
    draw();
  }
};

/* ================= Products ================= */
ROUTES.products = {
  title: 'Products',
  async render(main) {
    let offset = 0; const L = 50;
    main.innerHTML = `<div class="pagehead"><h1>Products</h1><div class="row">
      ${isAdmin() ? '<button class="btn primary" id="p-add">+ Add product</button><a class="btn" href="#/upload">Bulk upload</a>' : ''}
      <button class="btn" id="p-x">Export Excel</button></div></div>
      <div class="filters"><label class="f">Search SKU / name / barcode / brand<input id="f-q"></label>
        <label class="f">Brand<select id="f-brand">${optHtml([['', 'All brands']].concat(S.brands.map(b => [b, b])))}</select></label>
        <label class="f">Status<select id="f-act"><option value="1">Active</option><option value="">All</option><option value="0">Inactive</option></select></label>
        <button class="btn primary" id="f-go">Search</button></div><div id="tbl"></div><div id="pg"></div>`;
    const params = () => ({ q: $('#f-q').value, brand: $('#f-brand').value, active: $('#f-act').value });
    async function load() {
      const r = await api('/products?' + qs({ ...params(), limit: L, offset }));
      $('#tbl').innerHTML = table([
        { key: 'sku', label: 'SKU#' }, { key: 'name', label: 'Product name', wrap: 1 }, { key: 'brand', label: 'Brand' },
        { key: 'uom', label: 'UOM' }, { key: 'barcode', label: 'Barcode' }, { key: 'min_stock', label: 'Min stock' },
        { key: 'active', label: 'Status', render: p => p.active ? '' : '<span class="pill off">Inactive</span>' }], r.items, {
        empty: 'No products found. Add one or use Bulk upload.',
        actions: isAdmin() ? p => `<button class="btn sm" data-e="${p.id}">Edit</button> <button class="btn sm danger" data-d="${p.id}" data-n="${esc(p.sku)}">Delete</button>` : null });
      pager($('#pg'), r.total, offset, L, o => { offset = o; load(); });
      $$('[data-e]').forEach(b => b.onclick = () => productForm(r.items.find(p => p.id == b.dataset.e)));
      $$('[data-d]').forEach(b => b.onclick = async () => {
        if (!confirm(`Delete product ${b.dataset.n}?`)) return;
        try { const x = await api('/products/' + b.dataset.d, { method: 'DELETE' }); toast(x.message, 'ok'); load(); } catch (e) { toast(e.message, 'err'); }
      });
    }
    function productForm(p) {
      formModal(p ? 'Edit product' : 'Add product', [
        { name: 'sku', label: 'SKU#', required: true }, { name: 'barcode', label: 'Barcode' },
        { name: 'name', label: 'Product name', required: true, full: true },
        { name: 'brand', label: 'Brand' }, { name: 'uom', label: 'UOM', default: 'PCS' },
        { name: 'min_stock', label: 'Minimum stock (alert level)', type: 'number', default: 0 },
        { name: 'active', label: 'Active', type: 'checkbox', default: true }], p || {},
        async d => {
          await api(p ? '/products/' + p.id : '/products', { method: p ? 'PUT' : 'POST', body: d });
          S.brands = await api('/products/brands'); toast('Product saved', 'ok'); load();
        });
    }
    if (isAdmin()) $('#p-add').onclick = () => productForm(null);
    $('#f-go').onclick = () => { offset = 0; load().catch(e => toast(e.message, 'err')); };
    $('#f-q').addEventListener('keydown', e => { if (e.key === 'Enter') $('#f-go').click(); });
    $('#p-x').onclick = () => download('/products?' + qs({ ...params(), fmt: 'xlsx' }), 'products.xlsx');
    await load();
  }
};

/* ================= Bulk upload ================= */
function uploadCard(title, help, tplPath, tplName, endpoint, showResult) {
  const id = 'u' + Math.random().toString(36).slice(2, 7);
  return { html: `<div class="panel"><h2>${title}</h2><p class="muted small">${help}</p>
    <div class="row"><button class="btn" id="${id}-t">Download template</button>
      <input type="file" id="${id}-f" accept=".xlsx,.csv" style="max-width:340px">
      <button class="btn primary" id="${id}-u">Upload file</button></div><div class="result" id="${id}-r"></div></div>`,
    wire() {
      $('#' + id + '-t').onclick = () => download(tplPath, tplName);
      $('#' + id + '-u').onclick = async () => {
        const f = $('#' + id + '-f').files[0], out = $('#' + id + '-r');
        if (!f) return toast('Choose an .xlsx or .csv file first', 'err');
        const fd = new FormData(); fd.append('file', f);
        const btn = $('#' + id + '-u'); btn.disabled = true; out.innerHTML = '<span class="muted">Uploading…</span>';
        try { const r = await api(endpoint, { method: 'POST', form: fd }); out.innerHTML = showResult(r); S.brands = await api('/products/brands'); }
        catch (e) {
          const errs = e.data && e.data.errors || [];
          out.innerHTML = `<div class="err-text">${esc(e.message)}</div>` + (errs.length ? table([{ key: 'row', label: 'Row' }, { key: 'error', label: 'Problem', wrap: 1 }], errs) : '');
        }
        btn.disabled = false;
      };
    } };
}
ROUTES.upload = {
  title: 'Bulk upload',
  async render(main) {
    const errTable = r => r.error_count ? `<p class="err-text">${r.error_count} row(s) skipped:</p>` + table([{ key: 'row', label: 'Row' }, { key: 'error', label: 'Problem', wrap: 1 }], r.errors) : '';
    const cards = [uploadCard('Inbound / outbound transactions',
      'One row per item. Columns: Type (IN or OUT), Warehouse (code), Date (optional), Reference, SKU# (or barcode), Qty, Remarks. Rows with the same type, warehouse, date and reference become one document. If any row has a problem, nothing is saved.',
      '/docs/template', 'transactions_template.xlsx', '/docs/bulk',
      r => `<p style="color:var(--in);font-weight:650">Saved ${r.documents} document(s) with ${r.lines} line(s).</p><p class="muted small">${r.doc_nos.map(esc).join(', ')}</p>`)];
    if (isAdmin()) cards.push(uploadCard('Product database',
      'Columns: SKU#, Product Name, Brand, UOM, Barcode, Min Stock. New SKUs are added; existing SKUs are updated (blank cells keep the current value). Handles thousands of rows.',
      '/products/template', 'products_template.xlsx', '/products/bulk',
      r => `<p style="color:var(--in);font-weight:650">${r.created} added, ${r.updated} updated.</p>${errTable(r)}`));
    main.innerHTML = `<div class="pagehead"><h1>Bulk upload</h1></div>` + cards.map(c => c.html).join('');
    cards.forEach(c => c.wire());
  }
};

/* ================= Warehouses (admin) ================= */
ROUTES.warehouses = {
  title: 'Warehouses', admin: true,
  async render(main) {
    main.innerHTML = `<div class="pagehead"><h1>Warehouses</h1><button class="btn primary" id="w-add">+ Add warehouse</button></div><div id="tbl"></div>`;
    async function load() {
      S.whs = await api('/warehouses');
      $('#tbl').innerHTML = table([{ key: 'code', label: 'Code' }, { key: 'name', label: 'Name' }, { key: 'location', label: 'Location' },
        { key: 'active', label: 'Status', render: w => w.active ? 'Active' : '<span class="pill off">Inactive</span>' }], S.whs, {
        actions: w => `<button class="btn sm" data-e="${w.id}">Edit</button> <button class="btn sm danger" data-d="${w.id}" data-n="${esc(w.code)}">Delete</button>` });
      $$('[data-e]').forEach(b => b.onclick = () => form(S.whs.find(w => w.id == b.dataset.e)));
      $$('[data-d]').forEach(b => b.onclick = async () => {
        if (!confirm(`Delete warehouse ${b.dataset.n}?`)) return;
        try { const r = await api('/warehouses/' + b.dataset.d, { method: 'DELETE' }); toast(r.message, 'ok'); load(); } catch (e) { toast(e.message, 'err'); }
      });
    }
    function form(w) {
      formModal(w ? 'Edit warehouse' : 'Add warehouse', [
        { name: 'code', label: 'Code (e.g. MAIN, DXB1)', required: true }, { name: 'name', label: 'Name', required: true },
        { name: 'location', label: 'Location', full: true }, { name: 'active', label: 'Active', type: 'checkbox', default: true }], w || {},
        async d => { await api(w ? '/warehouses/' + w.id : '/warehouses', { method: w ? 'PUT' : 'POST', body: d }); toast('Warehouse saved', 'ok'); load(); });
    }
    $('#w-add').onclick = () => form(null);
    await load();
  }
};

/* ================= Users (admin) ================= */
ROUTES.users = {
  title: 'Users', admin: true,
  async render(main) {
    main.innerHTML = `<div class="pagehead"><h1>Users</h1><button class="btn primary" id="u-add">+ Add user</button></div><div id="tbl"></div>`;
    let users = [];
    const whName = id => (S.whs.find(w => w.id === id) || {}).code || 'All';
    async function load() {
      users = await api('/users');
      $('#tbl').innerHTML = table([{ key: 'username', label: 'Username' }, { key: 'full_name', label: 'Name' },
        { key: 'role', label: 'Role', render: u => u.role === 'admin' ? 'Admin' : 'Data entry' },
        { key: 'warehouse_id', label: 'Warehouse access', render: u => esc(whName(u.warehouse_id)) },
        { key: 'active', label: 'Status', render: u => u.active ? 'Active' : '<span class="pill off">Disabled</span>' }], users, {
        actions: u => `<button class="btn sm" data-e="${u.id}">Edit</button> <button class="btn sm danger" data-d="${u.id}" data-n="${esc(u.username)}">Delete</button>` });
      $$('[data-e]').forEach(b => b.onclick = () => form(users.find(u => u.id == b.dataset.e)));
      $$('[data-d]').forEach(b => b.onclick = async () => {
        if (!confirm(`Delete user ${b.dataset.n}?`)) return;
        try { const r = await api('/users/' + b.dataset.d, { method: 'DELETE' }); toast(r.message, 'ok'); load(); } catch (e) { toast(e.message, 'err'); }
      });
    }
    function form(u) {
      const wh = [['', 'All warehouses']].concat(S.whs.map(w => [w.id, `${w.code} – ${w.name}`]));
      formModal(u ? 'Edit user' : 'Add user', [
        { name: 'username', label: 'Username', required: true }, { name: 'full_name', label: 'Full name' },
        { name: 'password', label: u ? 'New password (leave blank to keep)' : 'Password (min 6)', type: 'password', required: !u, full: true },
        { name: 'role', label: 'Role', type: 'select', options: [['user', 'Data entry user'], ['admin', 'Admin']] },
        { name: 'warehouse_id', label: 'Warehouse access', type: 'select', options: wh },
        { name: 'active', label: 'Active', type: 'checkbox', default: true }], u || {},
        async d => {
          d.warehouse_id = d.warehouse_id ? Number(d.warehouse_id) : null; if (!d.password) delete d.password;
          await api(u ? '/users/' + u.id : '/users', { method: u ? 'PUT' : 'POST', body: d }); toast('User saved', 'ok'); load();
        });
    }
    $('#u-add').onclick = () => form(null);
    await load();
  }
};

boot();
