'use strict';
/* ---------- state & helpers ---------- */
const S = { token: localStorage.getItem('tok'), user: null, whs: [], brands: [], timer: null };
const ROUTES = {};
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const num = n => Number(n || 0).toLocaleString(undefined, { maximumFractionDigits: 3 });
const localToday = () => new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10);
const qs = o => Object.entries(o).filter(([, v]) => v !== '' && v != null && v !== false)
  .map(([k, v]) => encodeURIComponent(k) + '=' + encodeURIComponent(v)).join('&');
const isAdmin = () => S.user && S.user.role === 'admin';
const NUMKEYS = new Set(['total_in', 'total_out', 'on_hand', 'min_stock', 'qty', 'shortage', 'net', 'lines', 'total_qty']);

function errText(j) {
  const d = j && j.detail;
  if (!d) return 'Something went wrong';
  if (typeof d === 'string') return d;
  if (Array.isArray(d)) return d.map(x => (x.loc ? x.loc.slice(1).join('.') + ': ' : '') + x.msg).join('; ');
  return d.message || 'Something went wrong';
}

async function api(path, opt = {}) {
  const headers = {};
  if (S.token) headers.Authorization = 'Bearer ' + S.token;
  let body;
  if (opt.form) body = opt.form;
  else if (opt.body) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opt.body); }
  let r;
  try { r = await fetch('/api' + path, { method: opt.method || 'GET', headers, body }); }
  catch (e) { throw new Error('Cannot reach the server. Check your internet connection.'); }
  if (r.status === 401 && S.token) { logout(); throw new Error('Please sign in again'); }
  if (opt.blob && r.ok) return r.blob();
  const j = await r.json().catch(() => ({}));
  if (!r.ok) { const e = new Error(errText(j)); e.data = j.detail; throw e; }
  return j;
}

async function download(path, filename) {
  try {
    const blob = await api(path, { blob: true });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = filename; document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
  } catch (e) { toast(e.message, 'err'); }
}

function toast(msg, kind = '') {
  const t = document.createElement('div');
  t.className = 'toast ' + kind; t.textContent = msg;
  $('#toast').appendChild(t);
  setTimeout(() => t.remove(), kind === 'err' ? 6000 : 3200);
}

let audioCtx;
function beep(ok = true) {
  try {
    audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
    const o = audioCtx.createOscillator(), g = audioCtx.createGain();
    o.frequency.value = ok ? 880 : 220; g.gain.value = 0.08;
    o.connect(g); g.connect(audioCtx.destination); o.start(); o.stop(audioCtx.currentTime + (ok ? 0.09 : 0.25));
  } catch (e) { /* sound is optional */ }
  if (navigator.vibrate) navigator.vibrate(ok ? 30 : [60, 40, 60]);
}

function loadScript(src) {
  return new Promise((res, rej) => {
    if ($(`script[src="${src}"]`)) return res();
    const s = document.createElement('script'); s.src = src; s.onload = res;
    s.onerror = () => rej(new Error('Could not load the scanner. Check your internet connection.'));
    document.head.appendChild(s);
  });
}

/* ---------- modal ---------- */
function openModal(html, wide = false) {
  closeModal();
  const b = document.createElement('div'); b.className = 'backdrop';
  b.innerHTML = `<div class="modal ${wide ? 'wide' : ''}" role="dialog" aria-modal="true">${html}</div>`;
  b.addEventListener('mousedown', e => { if (e.target === b && !b.dataset.lock) closeModal(); });
  $('#modal-root').appendChild(b);
  return b;
}
function closeModal() { if (window.__onModalClose) { const f = window.__onModalClose; window.__onModalClose = null; f(); } $('#modal-root').innerHTML = ''; }

/** fields: [{name,label,type:text|number|password|select|checkbox,options:[[value,label]],full,required}] */
function formModal(title, fields, values, onSave) {
  const inputs = fields.map(f => {
    const v = values[f.name] ?? (f.default ?? '');
    let ctl;
    if (f.type === 'select') ctl = `<select name="${f.name}">${f.options.map(([val, lab]) => `<option value="${esc(val)}" ${String(val) === String(v) ? 'selected' : ''}>${esc(lab)}</option>`).join('')}</select>`;
    else if (f.type === 'checkbox') return `<label class="chk ${f.full ? 'full' : ''}"><input type="checkbox" name="${f.name}" ${v === '' ? (f.default ? 'checked' : '') : (v ? 'checked' : '')}> ${esc(f.label)}</label>`;
    else ctl = `<input name="${f.name}" type="${f.type || 'text'}" ${f.type === 'number' ? 'step="any"' : ''} value="${esc(v)}" ${f.required ? 'required' : ''} autocomplete="off">`;
    return `<label class="f ${f.full ? 'full' : ''}">${esc(f.label)}${f.required ? ' *' : ''}${ctl}</label>`;
  }).join('');
  const b = openModal(`<h3>${esc(title)}</h3><form><div class="formgrid">${inputs}</div><div class="err-text" id="fm-err"></div><div class="actions"><button type="button" class="btn" id="fm-cancel">Cancel</button><button class="btn primary">Save</button></div></form>`);
  $('#fm-cancel', b).onclick = closeModal;
  const first = $('input,select', b); if (first) first.focus();
  $('form', b).onsubmit = async e => {
    e.preventDefault();
    const data = {};
    fields.forEach(f => {
      const el = $(`[name="${f.name}"]`, b);
      data[f.name] = f.type === 'checkbox' ? el.checked : f.type === 'number' ? Number(el.value || 0) : el.value;
    });
    const btn = $('.primary', b); btn.disabled = true;
    try { await onSave(data); closeModal(); }
    catch (err) { $('#fm-err', b).textContent = err.message; btn.disabled = false; }
  };
}

/* ---------- generic table + pager ---------- */
function table(cols, rows, opt = {}) {
  if (!rows.length) return `<div class="empty">${opt.empty || 'Nothing to show yet.'}</div>`;
  const head = cols.map(c => `<th class="${NUMKEYS.has(c.key) ? 'num' : ''}">${esc(c.label)}</th>`).join('') + (opt.actions ? '<th></th>' : '');
  const body = rows.map((r, i) => {
    const cls = opt.rowClass ? opt.rowClass(r) : '';
    return `<tr class="${cls}">` + cols.map(c => {
      const v = r[c.key];
      const inner = c.render ? c.render(r) : (NUMKEYS.has(c.key) ? num(v) : esc(v));
      return `<td class="${NUMKEYS.has(c.key) ? 'num' : ''} ${c.wrap ? 'wrap' : ''}">${inner}</td>`;
    }).join('') + (opt.actions ? `<td>${opt.actions(r, i)}</td>` : '') + '</tr>';
  }).join('');
  return `<div class="tablewrap"><table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>`;
}
function pager(el, total, offset, limit, go) {
  const from = total ? offset + 1 : 0, to = Math.min(offset + limit, total);
  el.innerHTML = `<div class="pager"><span class="muted">${from}–${to} of ${num(total)}</span><span class="row">
    <button class="btn sm" id="pg-prev" ${offset <= 0 ? 'disabled' : ''}>Previous</button>
    <button class="btn sm" id="pg-next" ${to >= total ? 'disabled' : ''}>Next</button></span></div>`;
  $('#pg-prev', el).onclick = () => go(Math.max(0, offset - limit));
  $('#pg-next', el).onclick = () => go(offset + limit);
}
const whOptions = (all = true, activeOnly = false) =>
  (all && !S.user.warehouse_id ? [['', 'All warehouses']] : [])
    .concat(S.whs.filter(w => !activeOnly || w.active).map(w => [w.id, `${w.code} – ${w.name}`]));
const optHtml = (opts, sel = '') => opts.map(([v, l]) => `<option value="${esc(v)}" ${String(v) === String(sel) ? 'selected' : ''}>${esc(l)}</option>`).join('');

/* ---------- auth ---------- */
function logout() {
  localStorage.removeItem('tok'); S.token = null; S.user = null; clearInterval(S.timer); showLogin();
}
function showLogin(msg = '') {
  $('#app').innerHTML = `<div class="login"><form id="lf"><h1 class="brand" style="color:var(--ink);padding:0"><i></i>Stockroom</h1>
    <p class="muted" style="margin:0">Sign in to manage warehouse stock.</p>
    <label class="f">Username<input id="lu" autocomplete="username" autocapitalize="none" required></label>
    <label class="f">Password<input id="lp" type="password" autocomplete="current-password" required></label>
    <div class="err-text" id="le">${esc(msg)}</div><button class="btn primary">Sign in</button></form></div>`;
  $('#lf').onsubmit = async e => {
    e.preventDefault();
    try {
      const r = await api('/auth/login', { method: 'POST', body: { username: $('#lu').value, password: $('#lp').value } });
      S.token = r.token; localStorage.setItem('tok', r.token); await boot();
    } catch (err) { $('#le').textContent = err.message; }
  };
}
function passwordModal() {
  formModal('Change password', [
    { name: 'old_password', label: 'Current password', type: 'password', required: true, full: true },
    { name: 'new_password', label: 'New password (min 6 characters)', type: 'password', required: true, full: true }], {},
    async d => { await api('/auth/password', { method: 'POST', body: d }); toast('Password changed', 'ok'); });
}

/* ---------- shell + router ---------- */
const NAV = [['dashboard', 'Dashboard'], ['in', 'Inbound', 0, 'in'], ['out', 'Outbound', 0, 'out'], ['docs', 'Transactions'],
  ['reports', 'Reports'], ['sep'], ['products', 'Products'], ['upload', 'Bulk upload'],
  ['warehouses', 'Warehouses', 1], ['users', 'Users', 1]];

function shell() {
  const links = NAV.filter(n => !n[2] || isAdmin()).map(n => n[0] === 'sep' ? '<div class="navsep"></div>' :
    `<a href="#/${n[0]}" data-r="${n[0]}"><span class="dot ${n[3] || ''}"></span>${n[1]}</a>`).join('');
  $('#app').innerHTML = `<div class="shell"><aside id="side"><div class="brand"><i></i>Stockroom</div><nav>${links}</nav>
    <div class="me"><b>${esc(S.user.full_name || S.user.username)}</b><span class="muted">${S.user.role === 'admin' ? 'Admin' : 'Data entry'}${S.user.warehouse_id ? ' · ' + esc((S.whs[0] || {}).code || '') : ''}</span><br>
    <button id="pw">Change password</button><button id="lo">Sign out</button></div></aside>
    <div class="scrim" id="scrim"></div>
    <div class="content"><header class="top"><button id="menu" aria-label="Open menu">☰</button><h1 id="ptitle"></h1></header><main id="main"></main></div></div>`;
  $('#menu').onclick = () => document.body.classList.add('nav-open');
  $('#scrim').onclick = () => document.body.classList.remove('nav-open');
  $('#pw').onclick = passwordModal; $('#lo').onclick = logout;
}

async function route() {
  clearInterval(S.timer); closeModal(); document.body.classList.remove('nav-open');
  const name = (location.hash.replace('#/', '') || 'dashboard').split('?')[0];
  const r = ROUTES[name] && (!ROUTES[name].admin || isAdmin()) ? ROUTES[name] : ROUTES.dashboard;
  const key = ROUTES[name] ? name : 'dashboard';
  $$('#side a').forEach(a => a.classList.toggle('on', a.dataset.r === key));
  $('#ptitle').textContent = r.title;
  const main = $('#main'); main.innerHTML = '';
  try { await r.render(main); } catch (e) { main.innerHTML = `<div class="panel err-text">${esc(e.message)}</div>`; }
  window.scrollTo(0, 0);
}

async function boot() {
  if (!S.token) return showLogin();
  try {
    S.user = await api('/auth/me');
    [S.whs, S.brands] = await Promise.all([api('/warehouses'), api('/products/brands')]);
  } catch (e) { return showLogin(); }
  shell();
  window.onhashchange = route;
  await route();
}
if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});
