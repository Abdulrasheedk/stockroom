'use strict';
/* ================= Dashboard ================= */
function barChart(series) {
  const W = 700, H = 200, pad = { l: 48, r: 6, t: 8, b: 24 };
  const max = Math.max(1, ...series.flatMap(s => [s.in, s.out]));
  const bw = (W - pad.l - pad.r) / series.length, h = H - pad.t - pad.b;
  const y = v => pad.t + h - (v / max) * h;
  let g = [0, .5, 1].map(f => `<line x1="${pad.l}" x2="${W - pad.r}" y1="${y(max * f)}" y2="${y(max * f)}" stroke="var(--line)"/><text x="${pad.l - 5}" y="${y(max * f) + 4}" text-anchor="end" font-size="11" fill="var(--muted)">${num(Math.round(max * f))}</text>`).join('');
  series.forEach((s, i) => {
    const x = pad.l + i * bw, w = bw * 0.36;
    g += `<rect x="${x + bw * .12}" y="${y(s.in)}" width="${w}" height="${pad.t + h - y(s.in)}" fill="var(--in)" rx="2"><title>${s.date} inbound ${num(s.in)}</title></rect>`;
    g += `<rect x="${x + bw * .12 + w + 2}" y="${y(s.out)}" width="${w}" height="${pad.t + h - y(s.out)}" fill="var(--out)" rx="2"><title>${s.date} outbound ${num(s.out)}</title></rect>`;
    g += `<text x="${x + bw / 2}" y="${H - 7}" text-anchor="middle" font-size="11" fill="var(--muted)">${s.date.slice(8)}</text>`;
  });
  return `<svg class="chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Inbound and outbound quantity for the last 14 days">${g}</svg>
    <div class="legend"><span><i style="background:var(--in)"></i>Inbound</span><span><i style="background:var(--out)"></i>Outbound</span></div>`;
}

ROUTES.dashboard = {
  title: 'Dashboard',
  async render(main) {
    main.innerHTML = `<div class="pagehead"><h1>Dashboard</h1><div class="row">
      ${S.user.warehouse_id ? '' : `<select id="dw" aria-label="Warehouse" style="width:auto">${optHtml(whOptions(true))}</select>`}
      <span class="muted small" id="upd"></span></div></div><div id="dash"></div>`;
    const load = async () => {
      const wid = $('#dw') ? $('#dw').value : '';
      const d = await api('/dashboard?' + qs({ warehouse_id: wid }));
      $('#upd').textContent = 'Updated ' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      $('#dash').innerHTML = `
      <div class="stats">
        <div class="stat"><b>${num(d.total_on_hand)}</b><span>Units on hand</span></div>
        <div class="stat"><b>${num(d.active_skus)}</b><span>Active SKUs</span></div>
        <div class="stat in"><b>${num(d.today.in)}</b><span>Inbound today</span></div>
        <div class="stat out"><b>${num(d.today.out)}</b><span>Outbound today</span></div>
        <div class="stat in"><b>${num(d.month.in)}</b><span>Inbound this month</span></div>
        <div class="stat out"><b>${num(d.month.out)}</b><span>Outbound this month</span></div>
        <div class="stat"><a href="#/reports?lowstock"><b style="color:${d.low_stock_count ? 'var(--warn)' : 'inherit'}">${num(d.low_stock_count)}</b><span>SKUs at or below minimum</span></a></div>
      </div>
      <div class="panel"><h2>Last 14 days</h2>${barChart(d.series)}</div>
      <div class="cols">
        <div class="panel"><h2>Stock by warehouse</h2>${d.by_warehouse.length ? `<ul class="list">${d.by_warehouse.map(w => `<li><span><b>${esc(w.code)}</b> <span class="muted">${esc(w.name)} · ${num(w.skus)} SKUs</span></span><b class="num">${num(w.on_hand)}</b></li>`).join('')}</ul>` : '<div class="empty">No stock movements yet. Record an inbound to get started.</div>'}</div>
        <div class="panel"><h2>Top outbound, last 30 days</h2>${d.top_out.length ? `<ul class="list">${d.top_out.map(t => `<li><span>${esc(t.sku)} <span class="muted">${esc(t.name)}</span></span><b class="num">${num(t.qty)}</b></li>`).join('')}</ul>` : '<div class="empty">No outbound in the last 30 days.</div>'}</div>
        <div class="panel"><h2>Recent transactions</h2>${d.recent.length ? `<ul class="list">${d.recent.map(r => `<li><span><span class="pill ${r.doc_type === 'IN' ? 'in' : 'out'}">${r.doc_type === 'IN' ? 'In' : 'Out'}</span> <a href="#/docs" data-doc="${r.id}">${esc(r.doc_no)}</a></span><span class="muted">${esc(r.warehouse)} · ${esc(r.reference || r.date)}</span></li>`).join('')}</ul>` : '<div class="empty">Nothing recorded yet.</div>'}</div>
      </div>`;
      $$('[data-doc]').forEach(a => a.onclick = e => { e.preventDefault(); showDoc(a.dataset.doc); });
    };
    await load();
    $('#dw') && ($('#dw').onchange = load);
    S.timer = setInterval(() => load().catch(() => {}), 30000); // live refresh across devices
  }
};

/* ================= Inbound / Outbound entry ================= */
function entryPage(type) {
  const isIn = type === 'IN';
  return async main => {
    const st = { lines: [], saving: false };
    const whs = S.whs.filter(w => w.active);
    if (!whs.length) { main.innerHTML = '<div class="panel">No active warehouse. Ask an admin to add one.</div>'; return; }
    main.innerHTML = `
    <div class="pagehead"><h1>${isIn ? 'Inbound – stock in' : 'Outbound – stock out'}</h1></div>
    <div class="panel"><div class="entry-head">
      <label class="f">Warehouse<select id="e-wh">${optHtml(whOptions(false, true))}</select></label>
      <label class="f">Date<input id="e-date" type="date" value="${localToday()}"></label>
      <label class="f">Reference (PO / DO / invoice)<input id="e-ref" autocomplete="off"></label>
      <label class="f">Remarks<input id="e-rem" autocomplete="off"></label></div></div>
    <div class="scanbar ${isIn ? '' : 'out'}">
      <input id="scan" placeholder="Scan or type SKU# / barcode, then Enter" autocomplete="off" autocapitalize="none" enterkeyhint="go" aria-label="SKU or barcode">
      <button class="btn ${isIn ? 'in' : 'out'}" id="scan-add">Add</button>
      <button class="btn" id="scan-cam">Scan with camera</button>
    </div>
    <div id="lines"></div>
    <div class="row" style="margin-bottom:12px"><button class="btn" id="add-row">+ Add blank row</button></div>
    <div class="entry-foot"><div><b id="tot-lines">0 lines</b> <span class="muted" id="tot-qty"></span></div>
      <div class="row"><button class="btn" id="clear">Clear all</button><button class="btn ${isIn ? 'in' : 'out'}" id="save">Save ${isIn ? 'inbound' : 'outbound'}</button></div></div>`;
    const wid = () => { const el = $('#e-wh'); return el ? Number(el.value) : 0; };
    const savedWh = localStorage.getItem('wh');
    if (savedWh && $$('#e-wh option').some(o => o.value === savedWh)) $('#e-wh').value = savedWh;
    const scan = $('#scan');
    scan.focus();

    function totals() {
      const q = st.lines.reduce((a, l) => a + (Number(l.qty) || 0), 0);
      $('#tot-lines').textContent = st.lines.length + (st.lines.length === 1 ? ' line' : ' lines');
      $('#tot-qty').textContent = st.lines.length ? '· total qty ' + num(q) : '';
    }
    function renderLines() {
      const box = $('#lines');
      if (!st.lines.length) { box.innerHTML = `<div class="empty panel">No items yet. Scan a barcode, type a SKU#, or add a blank row.</div>`; totals(); return; }
      box.innerHTML = st.lines.map((l, i) => {
        const over = !isIn && l.p && Number(l.qty) > (l.p.on_hand ?? Infinity);
        return `<div class="line ${isIn ? 'noh' : ''} ${l.err ? 'bad' : ''} ${over ? 'over' : ''}" data-i="${i}">
        <label class="f-sku"><span>SKU# / barcode</span><input data-k="code" value="${esc(l.code)}" autocomplete="off" autocapitalize="none"></label>
        <div class="f-name"><span>Product name</span><b>${l.p ? esc(l.p.name) : (l.err ? esc(l.err) : '<span class="muted">Enter SKU# to fill</span>')}</b></div>
        <div class="f-meta"><span>Brand</span><div>${esc(l.p ? l.p.brand : '')}</div></div>
        <div class="f-meta"><span>UOM</span><div>${esc(l.p ? l.p.uom : '')}</div></div>
        <div class="f-meta hide-sm"><span>Barcode</span><div>${esc(l.p ? l.p.barcode : '')}</div></div>
        ${isIn ? '' : `<div class="f-meta"><span>On hand</span><div class="f-oh">${l.p ? num(l.p.on_hand) : ''}</div></div>`}
        <label class="f-qty"><span>Qty</span><input data-k="qty" type="number" min="0" step="any" inputmode="decimal" value="${esc(l.qty)}"></label>
        <label class="f-rem"><span>Remarks</span><input data-k="remarks" value="${esc(l.remarks)}" autocomplete="off"></label>
        <button class="del" data-del="${i}" aria-label="Remove line ${i + 1}">✕</button></div>`;
      }).join('');
      totals();
    }
    async function lookup(code) { return api('/products/lookup?' + qs({ code, warehouse_id: wid() })); }
    async function addByCode(code) {
      code = code.trim(); if (!code) return;
      try {
        const p = await lookup(code);
        const ex = st.lines.find(l => l.p && l.p.id === p.id);
        if (ex) { ex.qty = (Number(ex.qty) || 0) + 1; ex.p = p; } else st.lines.unshift({ code: p.sku, p, qty: 1, remarks: '' });
        renderLines(); beep(true); return p;
      } catch (e) { toast(e.message, 'err'); beep(false); }
    }
    const boxEl = $('#lines');
    boxEl.addEventListener('input', e => {
      const i = e.target.closest('.line')?.dataset.i, k = e.target.dataset.k;
      if (i == null || !k || k === 'code') return;
      st.lines[i][k] = e.target.value; totals();
      if (k === 'qty' && !isIn) e.target.closest('.line').classList.toggle('over', st.lines[i].p && Number(e.target.value) > (st.lines[i].p.on_hand ?? Infinity));
    });
    boxEl.addEventListener('change', async e => {   // typing a SKU fills in the product from the database
      if (e.target.dataset.k !== 'code') return;
      const i = Number(e.target.closest('.line').dataset.i), l = st.lines[i];
      l.code = e.target.value.trim(); l.p = null; l.err = '';
      if (l.code) {
        try { l.p = await lookup(l.code); l.code = l.p.sku; } catch (er) { l.err = er.message; beep(false); }
      }
      renderLines();
      const el = $(`.line[data-i="${i}"] [data-k="${l.p ? 'qty' : 'code'}"]`); if (el) { el.focus(); el.select && el.select(); }
    });
    boxEl.addEventListener('click', e => {
      const d = e.target.closest('[data-del]'); if (!d) return;
      st.lines.splice(Number(d.dataset.del), 1); renderLines();
    });
    scan.addEventListener('keydown', async e => {
      if (e.key !== 'Enter') return; e.preventDefault();
      const v = scan.value; scan.value = ''; await addByCode(v); scan.focus();
    });
    $('#scan-add').onclick = async () => { const v = scan.value; scan.value = ''; await addByCode(v); scan.focus(); };
    $('#add-row').onclick = () => { st.lines.unshift({ code: '', p: null, qty: 1, remarks: '' }); renderLines(); $('.line [data-k="code"]').focus(); };
    $('#clear').onclick = () => { if (!st.lines.length || confirm('Remove all lines?')) { st.lines = []; renderLines(); } };
    $('#e-wh').onchange = async () => {   // refresh on-hand for the newly selected warehouse
      localStorage.setItem('wh', $('#e-wh').value);
      for (const l of st.lines) if (l.p) { try { l.p = await lookup(l.p.sku); } catch (e) { /* keep */ } }
      renderLines();
    };
    $('#scan-cam').onclick = () => openScanner(code => addByCode(code));
    $('#save').onclick = async () => {
      if (st.saving) return;
      const lines = st.lines.filter(l => l.code || l.p);
      if (!lines.length) return toast('Add at least one item', 'err');
      if (lines.some(l => !l.p)) return toast('Some lines have an unknown SKU/barcode. Fix or remove them.', 'err');
      if (lines.some(l => !(Number(l.qty) > 0))) return toast('Every line needs a quantity above 0', 'err');
      st.saving = true; $('#save').disabled = true;
      try {
        const r = await api('/docs', { method: 'POST', body: {
          doc_type: type, warehouse_id: wid(), doc_date: $('#e-date').value || null, reference: $('#e-ref').value,
          remarks: $('#e-rem').value, lines: lines.map(l => ({ code: l.p.sku, qty: Number(l.qty), remarks: l.remarks })) } });
        toast(`Saved ${r.doc_no}`, 'ok');
        st.lines = []; $('#e-ref').value = ''; $('#e-rem').value = ''; renderLines(); scan.focus();
      } catch (e) { toast(e.message, 'err'); }
      st.saving = false; $('#save').disabled = false;
    };
    renderLines();
  };
}
ROUTES.in = { title: 'Inbound', render: entryPage('IN') };
ROUTES.out = { title: 'Outbound', render: entryPage('OUT') };

/* ---------- camera scanner (continuous, real-time) ---------- */
async function openScanner(onCode) {
  try { await loadScript('https://cdn.jsdelivr.net/npm/html5-qrcode@2.3.8/html5-qrcode.min.js'); }
  catch (e) { return toast(e.message, 'err'); }
  const b = openModal(`<h3>Scan barcodes</h3><div id="reader"></div>
    <p class="muted" id="scan-msg" style="min-height:1.4em">Point the camera at a barcode. Each scan is added automatically.</p>
    <div class="actions"><button class="btn primary" id="scan-done">Done</button></div>`);
  b.dataset.lock = '1';
  const F = Html5QrcodeSupportedFormats;
  const qr = new Html5Qrcode('reader', { formatsToSupport: [F.EAN_13, F.EAN_8, F.UPC_A, F.UPC_E, F.CODE_128, F.CODE_39, F.ITF, F.QR_CODE, F.CODE_93], useBarCodeDetectorIfSupported: true, verbose: false });
  let last = '', lastAt = 0, stopped = false;
  const stop = async () => { if (stopped) return; stopped = true; try { await qr.stop(); qr.clear(); } catch (e) { /* already stopped */ } };
  window.__onModalClose = stop;
  $('#scan-done', b).onclick = closeModal;
  try {
    await qr.start({ facingMode: 'environment' }, { fps: 12, qrbox: (w, h) => ({ width: Math.min(w - 20, 320), height: Math.min(h - 20, 150) }) },
      async text => {
        const now = Date.now();
        if (text === last && now - lastAt < 2000) return;      // ignore repeat reads of the same label
        last = text; lastAt = now;
        const p = await onCode(text);
        const m = $('#scan-msg'); if (m) m.textContent = p ? `Added ${p.sku} – ${p.name}` : `Not found: ${text}`;
      }, () => {});
  } catch (e) {
    closeModal();
    toast('Camera not available. Allow camera access, and open the app over https. You can also type the code or use a Bluetooth scanner.', 'err');
  }
}

/* ================= Transactions list ================= */
async function showDoc(id) {
  try {
    const d = await api('/docs/' + id);
    openModal(`<h3><span class="pill ${d.doc_type === 'IN' ? 'in' : 'out'}">${d.doc_type === 'IN' ? 'Inbound' : 'Outbound'}</span> ${esc(d.doc_no)}</h3>
      <p class="muted small">${esc(d.doc_date)} · ${esc(d.warehouse)} – ${esc(d.warehouse_name)} · by ${esc(d.user)}<br>Reference: ${esc(d.reference) || '—'} · Remarks: ${esc(d.remarks) || '—'}</p>
      ${table([{ key: 'sku', label: 'SKU#' }, { key: 'name', label: 'Product name', wrap: 1 }, { key: 'brand', label: 'Brand' }, { key: 'uom', label: 'UOM' }, { key: 'barcode', label: 'Barcode' }, { key: 'qty', label: 'Qty' }, { key: 'remarks', label: 'Remarks' }], d.lines)}
      <div class="actions"><button class="btn primary" onclick="closeModal()">Close</button></div>`, true);
  } catch (e) { toast(e.message, 'err'); }
}
ROUTES.docs = {
  title: 'Transactions',
  async render(main) {
    let offset = 0; const L = 50;
    main.innerHTML = `<div class="pagehead"><h1>Transactions</h1><div class="row">
      <button class="btn" id="x-xlsx">Export Excel</button><button class="btn" id="x-csv">Export CSV</button></div></div>
      <div class="filters">
        <label class="f">Type<select id="f-type"><option value="">All</option><option value="IN">Inbound</option><option value="OUT">Outbound</option></select></label>
        <label class="f">Warehouse<select id="f-wh">${optHtml(whOptions(true))}</select></label>
        <label class="f">From<input id="f-from" type="date"></label><label class="f">To<input id="f-to" type="date"></label>
        <label class="f">Search doc no / reference<input id="f-q"></label>
        <button class="btn primary" id="f-go">Apply</button></div>
      <div id="tbl"></div><div id="pg"></div>`;
    const params = () => ({ doc_type: $('#f-type').value, warehouse_id: $('#f-wh').value, date_from: $('#f-from').value, date_to: $('#f-to').value, q: $('#f-q').value });
    async function load() {
      const r = await api('/docs?' + qs({ ...params(), limit: L, offset }));
      $('#tbl').innerHTML = table([
        { key: 'doc_no', label: 'Doc no' }, { key: 'doc_date', label: 'Date' },
        { key: 'type', label: 'Type', render: x => `<span class="pill ${x.doc_type === 'IN' ? 'in' : 'out'}">${x.type}</span>` },
        { key: 'warehouse', label: 'Warehouse' }, { key: 'reference', label: 'Reference' }, { key: 'lines', label: 'Lines' },
        { key: 'total_qty', label: 'Total qty' }, { key: 'user', label: 'By' }], r.items, {
        empty: 'No transactions match these filters.',
        actions: x => `<button class="btn sm" data-v="${x.id}">View</button> ${isAdmin() ? `<button class="btn sm danger" data-d="${x.id}" data-n="${esc(x.doc_no)}">Delete</button>` : ''}` });
      pager($('#pg'), r.total, offset, L, o => { offset = o; load(); });
      $$('[data-v]').forEach(b => b.onclick = () => showDoc(b.dataset.v));
      $$('[data-d]').forEach(b => b.onclick = async () => {
        if (!confirm(`Delete ${b.dataset.n}? Stock balances will be adjusted.`)) return;
        try { const r2 = await api('/docs/' + b.dataset.d, { method: 'DELETE' }); toast(r2.message, 'ok'); load(); } catch (e) { toast(e.message, 'err'); }
      });
    }
    $('#f-go').onclick = () => { offset = 0; load().catch(e => toast(e.message, 'err')); };
    $('#x-xlsx').onclick = () => download('/docs?' + qs({ ...params(), fmt: 'xlsx' }), 'transactions.xlsx');
    $('#x-csv').onclick = () => download('/docs?' + qs({ ...params(), fmt: 'csv' }), 'transactions.csv');
    await load();
  }
};
