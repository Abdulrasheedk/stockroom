import csv
import io
import os
import re
import uuid
from collections import defaultdict
from datetime import date, datetime

from fastapi import HTTPException, UploadFile
from fastapi.responses import StreamingResponse
from openpyxl import Workbook, load_workbook
from sqlalchemy import case, func, or_, select
from sqlalchemy.orm import Session

from .models import Product, StockDoc, StockLine, User, Warehouse

ALLOW_NEGATIVE = os.getenv("ALLOW_NEGATIVE_STOCK", "0") == "1"

# ---------------------------------------------------------------- file import
ALIASES = {
    "sku": "sku", "sku#": "sku", "sku no": "sku", "sku code": "sku", "item code": "sku", "code": "sku",
    "product name": "name", "name": "name", "description": "name", "product": "name", "item name": "name",
    "brand": "brand", "uom": "uom", "unit": "uom", "unit of measure": "uom",
    "barcode": "barcode", "bar code": "barcode", "ean": "barcode", "upc": "barcode",
    "min stock": "min_stock", "min qty": "min_stock", "reorder level": "min_stock", "min": "min_stock",
    "type": "type", "doc type": "type", "movement": "type", "direction": "type",
    "warehouse": "warehouse", "warehouse code": "warehouse", "wh": "warehouse",
    "date": "date", "doc date": "date", "reference": "reference", "ref": "reference",
    "ref no": "reference", "qty": "qty", "quantity": "qty",
    "remarks": "remarks", "remark": "remarks", "notes": "remarks", "note": "remarks",
}


def _cell(v) -> str:
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    if isinstance(v, datetime):
        return v.date().isoformat()
    if isinstance(v, date):
        return v.isoformat()
    return str(v).strip()


def read_table(file: UploadFile) -> list[dict]:
    """Read .xlsx or .csv into a list of dicts using normalised column names."""
    raw = file.file.read()
    name = (file.filename or "").lower()
    if name.endswith((".xlsx", ".xlsm")):
        ws = load_workbook(io.BytesIO(raw), read_only=True, data_only=True).active
        matrix = [list(r) for r in ws.iter_rows(values_only=True)]
    elif name.endswith((".csv", ".txt")):
        text = raw.decode("utf-8-sig", errors="replace")
        matrix = list(csv.reader(io.StringIO(text)))
    else:
        raise HTTPException(400, "Upload an .xlsx or .csv file")
    matrix = [r for r in matrix if any(_cell(c) for c in r)]
    if len(matrix) < 2:
        raise HTTPException(400, "File has no data rows")
    heads = []
    for h in matrix[0]:
        n = re.sub(r"[^a-z0-9#]+", " ", _cell(h).lower()).strip()
        heads.append(ALIASES.get(n, n))
    rows = []
    for i, r in enumerate(matrix[1:], start=2):
        d = {heads[j]: _cell(c) for j, c in enumerate(r) if j < len(heads)}
        d["_row"] = i
        rows.append(d)
    return rows


def parse_date(s: str) -> date:
    s = (s or "").strip()
    if not s:
        return date.today()
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%m/%d/%Y"):
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            pass
    raise ValueError(f"Bad date '{s}' (use YYYY-MM-DD)")


# ---------------------------------------------------------------- file export
def export_response(rows: list[dict], columns: list[dict], fmt: str, filename: str):
    keys = [c["key"] for c in columns]
    labels = [c["label"] for c in columns]
    if fmt == "csv":
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(labels)
        for r in rows:
            w.writerow([r.get(k, "") for k in keys])
        data = io.BytesIO(("\ufeff" + buf.getvalue()).encode("utf-8"))
        return StreamingResponse(
            data, media_type="text/csv",
            headers={"Content-Disposition": f'attachment; filename="{filename}.csv"'})
    wb = Workbook()
    ws = wb.active
    ws.append(labels)
    for r in rows:
        ws.append([r.get(k, "") for k in keys])
    for i, lab in enumerate(labels, start=1):
        width = max([len(str(lab))] + [len(str(r.get(keys[i - 1], ""))) for r in rows[:200]])
        ws.column_dimensions[ws.cell(1, i).column_letter].width = min(max(width + 2, 10), 45)
    ws.freeze_panes = "A2"
    out = io.BytesIO()
    wb.save(out)
    out.seek(0)
    return StreamingResponse(
        out, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{filename}.xlsx"'})


def template_response(headers: list[str], sample: list[list], filename: str):
    wb = Workbook()
    ws = wb.active
    ws.append(headers)
    for s in sample:
        ws.append(s)
    out = io.BytesIO()
    wb.save(out)
    out.seek(0)
    return StreamingResponse(
        out, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{filename}.xlsx"'})


# ---------------------------------------------------------------- stock logic
def signed_qty():
    return case((StockDoc.doc_type == "IN", StockLine.qty), else_=-StockLine.qty)


def onhand_for(db: Session, warehouse_id: int, product_ids: list[int]) -> dict[int, float]:
    if not product_ids:
        return {}
    q = (
        select(StockLine.product_id, func.sum(signed_qty()))
        .join(StockDoc, StockDoc.id == StockLine.doc_id)
        .where(StockDoc.warehouse_id == warehouse_id, StockLine.product_id.in_(product_ids))
        .group_by(StockLine.product_id)
    )
    return {pid: float(v or 0) for pid, v in db.execute(q)}


def find_product(db: Session, code: str, include_inactive: bool = False) -> Product | None:
    code = (code or "").strip()
    if not code:
        return None
    for cond in (Product.sku == code, Product.barcode == code,
                 func.lower(Product.sku) == code.lower()):
        q = select(Product).where(cond)
        if not include_inactive:
            q = q.where(Product.active.is_(True))
        p = db.execute(q.limit(1)).scalar_one_or_none()
        if p:
            return p
    return None


def create_doc(db: Session, user: User | None, doc_type: str, warehouse_id: int, doc_date: date | None,
               reference: str, remarks: str, lines: list[tuple[Product, float, str]]) -> StockDoc:
    wh = db.get(Warehouse, warehouse_id)
    if not wh or not wh.active:
        raise HTTPException(400, "Warehouse not found or inactive")
    if user and user.warehouse_id and user.warehouse_id != warehouse_id:
        raise HTTPException(403, "You do not have access to that warehouse")

    if doc_type == "OUT" and not ALLOW_NEGATIVE:
        need = defaultdict(float)
        for p, q, _ in lines:
            need[p.id] += q
        have = onhand_for(db, warehouse_id, list(need))
        prods = {p.id: p for p, _, _ in lines}
        for pid, q in need.items():
            if have.get(pid, 0) < q - 1e-9:
                raise HTTPException(
                    400, f"Not enough stock for {prods[pid].sku}: on hand {have.get(pid, 0):g}, requested {q:g}")

    doc_date = doc_date or date.today()
    doc = StockDoc(doc_no="TMP-" + uuid.uuid4().hex, doc_type=doc_type, warehouse_id=warehouse_id,
                   doc_date=doc_date, reference=reference.strip(), remarks=remarks.strip(),
                   created_by=user.id if user else None)
    for p, q, r in lines:
        doc.lines.append(StockLine(product_id=p.id, qty=q, remarks=r.strip()))
    db.add(doc)
    db.flush()
    doc.doc_no = f"{doc_type}-{doc_date:%Y%m%d}-{doc.id:06d}"
    return doc


def like(term: str) -> str:
    return f"%{term.strip()}%"


def search_products_cond(term: str):
    t = like(term)
    return or_(Product.sku.ilike(t), Product.name.ilike(t), Product.barcode.ilike(t), Product.brand.ilike(t))
