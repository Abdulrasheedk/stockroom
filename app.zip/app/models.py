from datetime import date, datetime
from typing import Optional

from sqlalchemy import Boolean, Date, DateTime, Float, ForeignKey, Index, Integer, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .database import Base


class Warehouse(Base):
    __tablename__ = "warehouses"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(30), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(120))
    location: Mapped[str] = mapped_column(String(200), default="")
    active: Mapped[bool] = mapped_column(Boolean, default=True)


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    username: Mapped[str] = mapped_column(String(60), unique=True, index=True)
    full_name: Mapped[str] = mapped_column(String(120), default="")
    password_hash: Mapped[str] = mapped_column(String(300))
    role: Mapped[str] = mapped_column(String(10), default="user")  # admin | user
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    # If set, this user can only work in / see this warehouse
    warehouse_id: Mapped[Optional[int]] = mapped_column(ForeignKey("warehouses.id"), nullable=True)


class Product(Base):
    __tablename__ = "products"
    id: Mapped[int] = mapped_column(primary_key=True)
    sku: Mapped[str] = mapped_column(String(60), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(250), index=True)
    brand: Mapped[str] = mapped_column(String(100), default="", index=True)
    uom: Mapped[str] = mapped_column(String(20), default="PCS")
    barcode: Mapped[str] = mapped_column(String(80), default="", index=True)
    min_stock: Mapped[float] = mapped_column(Float, default=0)
    active: Mapped[bool] = mapped_column(Boolean, default=True)


class StockDoc(Base):
    """One inbound (IN) or outbound (OUT) transaction with many lines."""
    __tablename__ = "stock_docs"
    id: Mapped[int] = mapped_column(primary_key=True)
    doc_no: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    doc_type: Mapped[str] = mapped_column(String(3), index=True)  # IN | OUT
    warehouse_id: Mapped[int] = mapped_column(ForeignKey("warehouses.id"), index=True)
    doc_date: Mapped[date] = mapped_column(Date, index=True)
    reference: Mapped[str] = mapped_column(String(120), default="", index=True)
    remarks: Mapped[str] = mapped_column(String(500), default="")
    created_by: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    lines: Mapped[list["StockLine"]] = relationship(
        back_populates="doc", cascade="all, delete-orphan", passive_deletes=True
    )
    warehouse: Mapped[Warehouse] = relationship()
    user: Mapped[Optional[User]] = relationship()


class StockLine(Base):
    __tablename__ = "stock_lines"
    id: Mapped[int] = mapped_column(primary_key=True)
    doc_id: Mapped[int] = mapped_column(ForeignKey("stock_docs.id", ondelete="CASCADE"), index=True)
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id"), index=True)
    qty: Mapped[float] = mapped_column(Float)
    remarks: Mapped[str] = mapped_column(String(300), default="")

    doc: Mapped[StockDoc] = relationship(back_populates="lines")
    product: Mapped[Product] = relationship()


Index("ix_docs_wh_date", StockDoc.warehouse_id, StockDoc.doc_date)
