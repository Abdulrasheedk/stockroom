import os
import re

from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker


def _clean_database_url(raw: str) -> str:
    """Accepts what people usually paste from Neon, e.g.  psql 'postgresql://user:pw@host/db?sslmode=require'
    and keeps only the address itself."""
    raw = (raw or "").strip()
    if not raw:
        return "sqlite:///./warehouse.db"  # local testing only
    if raw.startswith("sqlite"):
        return raw
    m = re.search(r"postgres(?:ql)?(?:\+\w+)?://[^\s'\"]+", raw)
    if not m:
        raise RuntimeError(
            "DATABASE_URL is not valid. It must start with postgresql:// (copy the connection string from Neon, "
            "without the word psql and without quotes).")
    # Force the psycopg2 driver explicitly (newer SQLAlchemy versions default to a different one)
    return re.sub(r"^postgres(?:ql)?(?:\+\w+)?://", "postgresql+psycopg2://", m.group(0))


DATABASE_URL = _clean_database_url(os.getenv("DATABASE_URL", ""))
if DATABASE_URL.startswith("sqlite"):
    _args = {"check_same_thread": False}
else:
    _args = {"connect_timeout": 20}
    print("Using PostgreSQL database at host:", DATABASE_URL.split("@")[-1].split("/")[0])

engine = create_engine(DATABASE_URL, connect_args=_args, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)


class Base(DeclarativeBase):
    pass


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
