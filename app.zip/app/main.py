import os
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import select

from .database import Base, SessionLocal, engine
from .models import User, Warehouse
from .routers import accounts, products, reports, stock
from .security import hash_password

STATIC = os.path.join(os.path.dirname(__file__), "static")


@asynccontextmanager
async def lifespan(_: FastAPI):
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        if not db.execute(select(User).limit(1)).first():
            db.add(User(username=os.getenv("ADMIN_USERNAME", "admin"), full_name="Administrator", role="admin",
                        password_hash=hash_password(os.getenv("ADMIN_PASSWORD", "admin123"))))
        if not db.execute(select(Warehouse).limit(1)).first():
            db.add(Warehouse(code="MAIN", name="Main Warehouse"))
        db.commit()
    yield


app = FastAPI(title="Warehouse Stock Manager", lifespan=lifespan)
for r in (accounts.router, products.router, stock.router, reports.router):
    app.include_router(r)


@app.get("/health")
def health():
    return {"ok": True}


@app.get("/sw.js", include_in_schema=False)
def sw():
    return FileResponse(os.path.join(STATIC, "sw.js"), media_type="application/javascript",
                        headers={"Cache-Control": "no-cache"})


app.mount("/", StaticFiles(directory=STATIC, html=True), name="static")
