from datetime import date
from typing import Literal, Optional

from pydantic import BaseModel, Field


class LoginIn(BaseModel):
    username: str
    password: str


class PasswordIn(BaseModel):
    old_password: str
    new_password: str = Field(min_length=6)


class UserIn(BaseModel):
    username: str = Field(min_length=2)
    full_name: str = ""
    password: Optional[str] = None
    role: Literal["admin", "user"] = "user"
    active: bool = True
    warehouse_id: Optional[int] = None


class WarehouseIn(BaseModel):
    code: str = Field(min_length=1)
    name: str = Field(min_length=1)
    location: str = ""
    active: bool = True


class ProductIn(BaseModel):
    sku: str = Field(min_length=1)
    name: str = Field(min_length=1)
    brand: str = ""
    uom: str = "PCS"
    barcode: str = ""
    min_stock: float = 0
    active: bool = True


class LineIn(BaseModel):
    code: str  # SKU or barcode
    qty: float = Field(gt=0)
    remarks: str = ""


class DocIn(BaseModel):
    doc_type: Literal["IN", "OUT"]
    warehouse_id: int
    doc_date: Optional[date] = None
    reference: str = ""
    remarks: str = ""
    lines: list[LineIn] = Field(min_length=1)
